
class ResultBase():
    pass